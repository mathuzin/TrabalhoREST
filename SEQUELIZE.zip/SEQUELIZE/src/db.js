import { Sequelize } from "sequelize"; // importar o sequelize
import dotenv from "dotenv"; // importar o dotenv

dotenv.config(); // carregar as variáveis de ambiente

const dbName = process.env.DB_NAME; // pegar as variáveis do .env
const dbUser = process.env.DB_USER;
const dbHost = process.env.DB_HOST;
const dbPassword = process.env.DB_PASSWORD;

const sequelize = new Sequelize(dbName, dbUser, dbPassword, {
  dialect: "mysql", // o banco de dados usado (neste caso MySQL)
  host: dbHost, // o host (neste caso localhost)
});

export default sequelize; // exportar o objeto sequelize para ser usado em outros arquivos
  
