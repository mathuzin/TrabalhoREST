import express from "express";
import filmes from "./src/controllers/filmes.js";
import user from "./src/controllers/user.js";
import avaliacao from "./src/controllers/avaliacao.js";

const routes = express.Router();

//Chama os métodos do CRUD de filmes 
routes.get("/filmes", filmes.findAll); // Certo
routes.get("/filmes/:id", filmes.findFilme); // Certo 
//selects extra
routes.get("/filmes/genero/:genero", filmes.findByGenero); // Certo
routes.get("/filmes/distribuidora/:distribuidora", filmes.findByDistribuidora); // Certo
//
routes.post("/filmes", user.verifyJWT, filmes.addFilme); // Certo
routes.put("/filmes/:id", user.verifyJWT, filmes.updateFilme); // Certo
routes.delete("/filmes/:id", user.verifyJWT, filmes.deleteFilme); // Certo
routes.delete("/filmes", user.verifyJWT, filmes.deleteFilmes); // Certo

//Chama os métodos do CRUD de usuarios
routes.get("/usuario", user.findUsers); // Certo
routes.get("/usuario/:id", user.findUser); // Certo
//selects extra
routes.get("/usuario/nome/:nome", user.findByNome); // Certo
routes.get("/usuario/email/:email", user.findByEmail); // Certo
// uma rota post para registrar usuario
routes.post("/registrar", user.registerUser); // Certo
// e outra rota post para fazer o login do usuario
routes.post("/login", user.loginUser); // Certo
//logout
routes.post("/logout", user.logout); // Certo
//
routes.put("/usuario/:id", user.verifyJWT, user.updateUser); // Certo
routes.delete("/usuario/:id", user.verifyJWT, user.deleteUsers); // Certo

//Chama os métodos do CRUD de avaliação
routes.get("/avaliacao", avaliacao.findAvaliacoes); // Certo
routes.get("/avaliacao/:id", avaliacao.findAvaliacao); // Certo
// selects extra
routes.get("/avaliacao/usuarioId/:idUser", avaliacao.findAvaliacoesByUsuario); // Certo
routes.get("/avaliacao/filmeId/:idFilme", avaliacao.findAvaliacoesByFilme); // Certo
//
routes.post("/avaliacao", user.verifyJWT, avaliacao.addAvaliacao); // Certo
routes.put("/avaliacao/:id", user.verifyJWT, avaliacao.updateAvaliacao); // Certo
routes.delete("/avaliacao", user.verifyJWT, avaliacao.deleteAvaliacaos); // Certo
routes.delete("/avaliacao/:id", user.verifyJWT, avaliacao.deleteAvaliacao) // Certo

export { routes as default };