import express from "express";
import filmes from "./src/controllers/filmes.js";
import user from "./src/controllers/user.js";
import avaliacao from "./src/controllers/avaliacao.js";

const routes = express.Router();

//Chama os métodos do CRUD de filmes 
routes.get("/filmes", filmes.findAll);
routes.post("/filmes", filmes.addFilme);
routes.get("/filmes/:id", filmes.findFilme);
routes.put("/filmes/:id", filmes.updateFilme);
routes.delete("/filmes/:id", filmes.deleteFilme);
routes.delete("/filmes", filmes.deleteFilmes)

//Chama os métodos do CRUD de usuarios
routes.get("/usuario", user.findUsers);
routes.get("/usuario/:id", user.findUser);
routes.post("/usuario", user.addUser);
routes.put("/usuario/:id", user.updateUser);
routes.delete("/usuario/:id", user.deleteUsers);

//Chama os métodos do CRUD de avaliação
routes.get("/avaliacao", avaliacao.findAvaliacoes);
routes.get("/avaliacao/:id", avaliacao.findAvaliacao);
routes.post("/avaliacao", avaliacao.addAvaliacao);
routes.put("/avaliacao/:id", avaliacao.updateAvaliacao);
routes.put("/avaliacao", avaliacao.deleteAvaliacaos);
routes.put("/avaliacao/:id", avaliacao.deleteAvaliacao)

export { routes as default };
