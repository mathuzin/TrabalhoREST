import express from "express";
import filmes from "./src/controllers/filmes.js";

const routes = express.Router();

routes.get("/filmes", filmes.findAll);
routes.post("/filmes", filmes.addFilme);
routes.get("/filmes/:id", filmes.findFilme);
routes.put("/filmes/:id", filmes.updateFilme);
routes.delete("/filmes/:id", filmes.deleteFilmes);

export { routes as default };
