import { Sequelize } from "sequelize";
import db from "../db.js";

export default db.define("filme", {
  id: {
    type: Sequelize.INTEGER.UNSIGNED,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false,
  },
  nome: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  distribuidora: {
    type: Sequelize.STRING,
    allowNull: false,
  },
});

