import bcrypt from "bcrypt";
import userRepository from "../models/usuarioModels.js";

function findUsers(req, res) {
  userRepository.findAll().then((result) => res.json(result));
}

function findUser(req, res) {
  userRepository.findByPk(req.params.id).then((result) => res.json(result));
}

async function registerUser(req, res) {
  
    const nome = req.body.nome;
    const email = req.body.email;
    const senha = req.body.senha;

    const existeUsuario = await userRepository.findOne({ where: {email} });
    if (existeUsuario) {
      return res.json({ error: "Email já está em uso"});
    }

    const senhaCrypt = await bcrypt.hash(senha, 5);

    const novoUsuario = await userRepository.create({
      nome,
      email,
      senha: senhaCrypt,
    });

    res.json(novoUsuario);
    
}

function addUser(req, res) {
  userRepository.create({
    nome: req.body.nome,
    email: req.body.email,
  }).then((result) => res.json(result));
}

async function updateUser(req, res) {
  await userRepository.update(
    {
      nome: req.body.nome,
      email: req.body.email,
    },
    {
      where: {
        id: req.params.id,
      },
    }
  );

  userRepository.findByPk(req.params.id).then((result) => res.json(result));
}

async function deleteUsers(req, res) {
  try {
    await userRepository.destroy({ where: {} });

    const usuariosAtualizados = await userRepository.findAll();
    res.json(usuariosAtualizados);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao deletar os usuarios'});
  }
}

export default {findUsers, findUser, addUser, findUser, updateUser, deleteUsers};
