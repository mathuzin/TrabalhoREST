import filmRepository from "../models/filmesModels.js";

function findAll(req, res) {
    filmRepository.findAll().then((result) => res.json(result));
}

function findFilme(req, res) {
    filmRepository.findByPk(req.params.id).then((result) => res.json(result));
}

function addFilme(req, res) {
    filmRepository.create({
        nome: req.body.nome,
        distribuidora: req.body.distribuidora,
        diretor: req.body.diretor,
        elenco: req.body.elenco,
        genero: req.body.genero,
        ano_lancamento: req.body.ano_lancamento,
    }).then((result) => res.json(result));
}

async function updateFilme(req, res) {
    await filmRepository.update(
        {
            nome: req.body.nome,
            distribuidora: req.body.distribuidora,
            diretor: req.body.diretor,
            elenco: req.body.elenco,
            genero: req.body.genero,
            ano_lancamento: req.body.ano_lancamento,
        },
        {
            where: {
                id: req.params.id,
            },
        }
    );

    filmRepository.findByPk(req.params.id).then((result) => res.json(result));
}

async function deleteFilmes(req, res) {
    try {
        await filmRepository.destroy({ where: {} });

        const filmesAtualizados = await filmRepository.findAll();
        res.json(filmesAtualizados);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao deletar os filmes' });
    }
}

async function deleteFilme(req, res) {
    try {
        await filmRepository.destroy({
                where:
                {
                    id: req.params.id,
                },
            });

        const filmesAtualizados = await filmRepository.findAll();
        res.json(filmesAtualizados);
    } catch (error) {
        res.status(500).json({ error: 'Erro ao deletar os filmes' });
    }
}
export default { findAll, addFilme, findFilme, updateFilme, deleteFilmes, deleteFilme };
