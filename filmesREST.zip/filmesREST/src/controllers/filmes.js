import ClientRepository from "../models/filmesModels.js";

function findAll(req, res) {
  ClientRepository.findAll().then((result) => res.json(result));
}

function findFilme(req, res) {
  ClientRepository.findByPk(req.params.id).then((result) => res.json(result));
}

function addFilme(req, res) {
  ClientRepository.create({
    nome: req.body.nome,
    distribuidora: req.body.distribuidora,
  }).then((result) => res.json(result));
}

async function updateFilme(req, res) {
  await ClientRepository.update(
    {
      nome: req.body.nome,
      distribuidora: req.body.distribuidora,
    },
    {
      where: {
        id: req.params.id,
      },
    }
  );

  ClientRepository.findByPk(req.params.id).then((result) => res.json(result));
}

async function deleteFilmes(req, res) {
  try {
    await ClientRepository.destroy({ where: {} });

    const filmesAtualizados = await ClientRepository.findAll();
    res.json(filmesAtualizados);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao deletar os filmes'});
  }
}

export default { findAll, addFilme, findFilme, updateFilme, deleteFilmes };
